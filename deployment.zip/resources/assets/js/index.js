window.$ = window.jQuery = require('jquery');
require('bootstrap/dist/js/bootstrap.min');
require('nicescroll');
require('./scripts');
require('./custom');

import '../style/index.scss';